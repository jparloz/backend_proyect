<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StorePlatformsRequest extends FormRequest
{

    public function rules(): array
    {
        return [
            //
        ];
    }
}
