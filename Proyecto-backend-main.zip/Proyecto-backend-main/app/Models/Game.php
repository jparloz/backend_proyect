<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;


/**
 * App\Models\Game
 *
 * @property-read \App\Models\Game|null $developer
 * @method static \Database\Factories\GameFactory factory($count = null, $state = [])
 * @method static \Illuminate\Database\Eloquent\Builder|Game newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Game newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Game query()
 * @property int $id
 * @property int $publisher_id
 * @property int $developer_id
 * @property int $requirement_id
 * @property string $slug
 * @property string $name
 * @property string $release
 * @property string $background_image
 * @property string $rating
 * @property string $age_rating
 * @property string $playtime
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Genre> $genre
 * @property-read int|null $genre_count
 * @property-read \Illuminate\Database\Eloquent\Collection<int, \App\Models\Platform> $platforms
 * @property-read int|null $platforms_count
 * @property-read \App\Models\Requirement|null $requirement
 * @method static \Illuminate\Database\Eloquent\Builder|Game whereAgeRating($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Game whereBackgroundImage($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Game whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Game whereDeveloperId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Game whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Game whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Game wherePlaytime($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Game wherePublisherId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Game whereRating($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Game whereRelease($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Game whereRequirementId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Game whereSlug($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Game whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class Game extends Model
{
    use HasFactory;

    protected $fillable = [
        'id',
        'name',
        'slug',
        'platforms',
        'release',
        'background_image',
        'description',
        'rating',
        'age_rating',
        'developer_id',
        'requirement_id',
        'genres',
        'playtime',
        'meta_rating'
    ];

    //protected $hidden = ['id'];

    public function developer(): BelongsTo
    {
        return $this->belongsTo(Developer::class);
    }
    public function requirement(): BelongsTo
    {
        return $this->belongsTo(Requirement::class);
    }
    public function comments(): HasMany
    {
        return $this->HasMany(Comment::class);
    }
    public function platforms():BelongsToMany
    {
        //games_platform
        return $this->belongsToMany(Platform::class,'game_platform');
    }
    public function genres():BelongsToMany
    {
        //game_genre
        return $this->belongsToMany(Genre::class,'game_genre');
    }

    //id, Nombre, slug, platforms[], release, background_image, rating_metacritic, Age rating, ID_Publisher, ID_developer, generes[], requisitosPC, playtime

    //publiser : id, nombre, slug  *
    //developer: id, nombre, slug  *
    //platforms: id, nombre, slug *
    //review: id, id_user, id_game, review, nota *
    //generes: id, nombre, slug *
    //report: id, id_user, comentario *

}
